set -euo pipefail
out="$(node --input-type=module -e 'import {join} from "node:path"; console.log(join(process.env.RUNNER_TEMP,"omp-installed-acceptance").replaceAll("\\", "/"));')"
mkdir -p "$out"
echo "out=$out" >> "$GITHUB_OUTPUT"
installer="$(node --input-type=module -e 'import {resolve} from "node:path"; const v=process.argv[1]; const names={darwin:`OMP-Desktop-${v}-arm64.dmg`,win32:`OMP-Desktop-Setup-${v}.exe`,linux:`OMP-Desktop-${v}-x86_64.AppImage`}; console.log(resolve("apps/desktop/release",names[process.platform]));' "0.15.2")"
command=(node scripts/e2e-installed-smoke.mjs "$installer" "$out")
if [[ "darwin" == "linux" ]]; then
  command=(xvfb-run -a -s "-screen 0 1440x1000x24" "${command[@]}")
fi
set +e
"${command[@]}" > "$out/installed.stdout.txt" 2> "$out/installed.stderr.txt"
status=$?
set -e
cat "$out/installed.stdout.txt" "$out/installed.stderr.txt"
node scripts/report-installed-ci.mjs "$out"
exit "$status"
