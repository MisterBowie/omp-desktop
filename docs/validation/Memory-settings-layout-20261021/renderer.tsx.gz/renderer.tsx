import {createRoot} from 'react-dom/client';
import {createInstance} from 'i18next';
import {I18nextProvider,useTranslation} from 'react-i18next';
import {catalogs} from '@pi-desktop/i18n';
import {MemorySettingsPage} from '../../apps/desktop/src/features/settings/MemorySettingsPage';
import {api} from '../../apps/desktop/src/lib/api';
import {useAppStore} from '../../apps/desktop/src/stores/app-store';
const project='/layout-fixture/家政项目（这是一段较长的项目名称，用于窄窗口显示检查）';let mode='empty';let settings={autoSave:true,autoRead:true};
api.listProjects=async()=>({projects:[{path:project,displayName:'家政项目（较长的项目名称，用于检查窄窗口截断）'}]});
api.getOmpMemorySettings=async()=>settings;
api.setOmpMemorySettings=async value=>(settings=value);
api.queryOmpMemory=async()=>({items:mode==='empty'?[]:[{id:'fixture',content:'项目数据库使用 PostgreSQL。\n这是用于验证换行的记忆示例。\nhttps://example.test/'+ 'long-path-'.repeat(60)}],total:mode==='empty'?0:1,offset:0});
api.clearOmpMemory=async()=>({cleared:true});
useAppStore.setState({workspace:{path:project}});
const i18n=createInstance();await i18n.init({lng:'zh-CN',fallbackLng:'en',resources:Object.fromEntries(Object.entries(catalogs).map(([key,value])=>[key,{translation:value}]))});
function Page(){const {t}=useTranslation();return <><h1 className="settings-section-title">{t('memory.title')}</h1><MemorySettingsPage/></>;}
createRoot(document.getElementById('fixture')!).render(<I18nextProvider i18n={i18n}><Page/></I18nextProvider>);
const frame=()=>new Promise(resolve=>requestAnimationFrame(resolve));
const until=async(condition)=>{const deadline=performance.now()+5000;while(!condition()&&performance.now()<deadline)await frame();if(!condition())throw Error('fixture did not settle');};
const bounds=el=>{if(!el)return null;const r=el.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height,right:r.right,bottom:r.bottom};};
globalThis.inspectMemory=async(next='empty',lang='zh-CN',confirm=false)=>{
 await until(()=>!!document.querySelector('select option:nth-child(2)')&&!document.querySelector('[role="switch"]').disabled);
 mode=next;await i18n.changeLanguage(lang);await frame();await frame();
 const refresh=document.querySelector('.memory-settings-search button:last-child');refresh.click();await frame();await frame();
 await until(()=>!refresh.disabled);
 const clear=[...document.querySelectorAll('button')].find(b=>b.textContent===i18n.t('memory.clear'));if(confirm){clear.click();await frame();await frame();}
 const form=document.querySelector('.memory-settings-search');const input=form.querySelector('input');const buttons=[...form.querySelectorAll('button')];const panel=document.querySelectorAll('.settings-card-block')[1].querySelector('.settings-panel');
 const page=document.querySelector('.memory-settings-page')||panel;const controls=[...panel.querySelectorAll('button,input,select')].map(bounds);const results=[...panel.querySelectorAll('article')].map(el=>({client:el.clientWidth,scroll:el.scrollWidth}));
 return {headings:[...document.querySelectorAll('h1,h3')].map(h=>h.textContent),viewport:innerWidth,page:{client:page.clientWidth,scroll:page.scrollWidth},panel:bounds(panel),input:bounds(input),search:bounds(buttons[0]),refresh:bounds(buttons[1]),gap:getComputedStyle(form).columnGap,panelPadding:getComputedStyle(panel).padding,browser:bounds(document.querySelector('.memory-settings-browser')),controls,results};
};
